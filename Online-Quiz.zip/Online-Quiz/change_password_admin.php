<?php
 error_reporting(0);
require('database.php');
if(isset($_POST['submit']))
{
    $newpass = $_POST['new_password'];
    $confmpass = $_POST['confirm_password'];
    $email = $_POST['email'];
    if($newpass!=$confmpass)
    {
        echo "<script>alert('Password don\'t match')</script>";
        header("refresh:0;url='change_password_admin.php'");
    }
    else
    {
        
        $str = "UPDATE admin set password='$newpass' where admin.email='$email'";
		$query = "SELECT email from admin where admin.email='$email'";
        $res = mysqli_query($con,$str);
		$output = mysqli_query($con,$query);
        if($res==1 && mysqli_fetch_column($output) == $email)
        {
            echo "<script>alert('Password changed successfully!')</script>";
            header("refresh:0;url='admin.php'");
        }
		else
		{
			echo "<script>alert('Please check the user name once again');</script>";
			header("refresh:0;url='change_password_admin.php'");
		}
        
        
    }
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Change password | Online integrated quiz system</title>
		<link rel="stylesheet" href="scripts/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" href="scripts/ionicons/css/ionicons.min.css">
		<link rel="shotcut icon" type="image/png" href="image/book.png" />
		<link rel="stylesheet" href="css/form.css">
        <style type="text/css">
            body{
                  width: 100%;
                  background: url(quiz_bulb.jpeg) ;
                  background-position: center center;
                  background-repeat: no-repeat;
                  background-attachment: fixed;
                  background-size: cover;
                }
          </style>
	</head>

	<body>
		<section class="login first grey">
			<div class="container">
				<div class="box-wrapper">				
					<div class="box box-border">
						<div class="box-body">
						<center> <h5 style="font-family: 'Times New Roman';">Admin</h5><h4 style="font-family: 'Times New Roman', Times, serif;">Forgot password?</h4></center>
							<form method="post" action="change_password_admin.php" enctype="multipart/form-data">
								<div class="form-group">
                                    <label>Enter Your email id</label>
                                    <input required type="email" name="email" class="form-control">
									<label>Enter new password:</label>
									<input required type="password"  name="new_password" class="form-control">
								</div>
								<div class="form-group">
									<label class="fw">Confirm password:
									</label>
									<input required type="password" name="confirm_password" class="form-control">
								</div> 
								<div class="form-group text-right">
									<button class="btn btn-primary btn-block" name="submit">Submit</button>
            </div>
						
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>

		<script src="js/jquery.js"></script>
		<script src="scripts/bootstrap/bootstrap.min.js"></script>
	</body>
</html>